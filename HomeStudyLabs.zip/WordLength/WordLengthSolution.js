function wordLength(arr) {
//code goes here

}

module.exports = wordLength;