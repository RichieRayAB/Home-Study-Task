function wordCount(arrayOfStrings) {

}

module.exports = wordCount;