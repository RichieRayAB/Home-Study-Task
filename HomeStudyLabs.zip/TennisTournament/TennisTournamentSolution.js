

function solution(P, C) {
    //Provide Your solution here 

}

module.exports = solution;